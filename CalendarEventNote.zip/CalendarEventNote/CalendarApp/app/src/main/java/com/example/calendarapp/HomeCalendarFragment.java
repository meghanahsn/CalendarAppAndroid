package com.example.calendarapp;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

public class HomeCalendarFragment extends Fragment {

    private CustomCalendarView customCalendarView;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle savedInstanceState){

        View view = inflater.inflate(R.layout.home_calendar_layout, viewGroup, false);
        customCalendarView = (CustomCalendarView)view.findViewById(R.id.custom_calendar_view);
        return view;

    }

}
